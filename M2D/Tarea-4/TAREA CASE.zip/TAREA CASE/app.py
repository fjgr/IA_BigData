from flask import Flask, render_template, request, send_file, send_from_directory
import os
import subprocess

app = Flask(__name__)

# Ruta para los archivos generados
UPLOAD_FOLDER = os.path.join(os.getcwd(), 'generated_files')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Ruta principal
@app.route('/')
def serve_uml():
    # Renderizar el archivo HTML desde la carpeta templates
    return render_template('index.html')

# Ruta para guardar el archivo XMI
@app.route('/save-xmi', methods=['POST'])
def save_xmi():
    try:
        # Guardar el archivo XMI en la carpeta generated_files
        xmi_content = request.data.decode('utf-8')
        xmi_path = os.path.join(UPLOAD_FOLDER, 'diagram.xmi')
        with open(xmi_path, 'w', encoding='utf-8') as f:
            f.write(xmi_content)
        
        # Ejecutar Traductor.py
        clp_path = os.path.join(UPLOAD_FOLDER, 'output.clp')
        subprocess.run(['python', 'Traductor.py'], check=True)
        
        # Ejecutar clp_to_java.py y redirigir la salida a output.java
        java_path = os.path.join(UPLOAD_FOLDER, 'output.java')
        with open(java_path, 'w') as f:
            subprocess.run(['python', 'clp_to_java.py'], stdout=f, check=True)
        
        # Enviar el archivo Java como respuesta
        return send_file(java_path,
                         mimetype='application/java',
                         as_attachment=True,
                         download_name='output.java')

    except Exception as e:
        print(f"Error: {e}")
        return str(e), 500

# Ruta para subir el archivo XMI
@app.route('/upload-xmi', methods=['POST'])
def upload_xmi():
    try:
        file = request.files['file']
        if file:
            file_path = os.path.join(UPLOAD_FOLDER, 'diagram.xmi')
            file.save(file_path)
            return "Archivo XMI subido correctamente"
        return "No se pudo subir el archivo", 400
    except Exception as e:
        print(f"Error: {e}")
        return str(e), 500

# Ruta para servir archivos estáticos (JavaScript, CSS, etc.)
@app.route('/static/<path:path>')
def serve_static(path):
    return send_from_directory('static', path)

# Ruta para descargar un archivo generado
@app.route('/generated_files/<path:filename>')
def download_file(filename):
    return send_from_directory(UPLOAD_FOLDER, filename, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
