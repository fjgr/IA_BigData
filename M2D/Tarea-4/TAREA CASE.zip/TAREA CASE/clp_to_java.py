import clips
import os
import sys

def convert_clp_to_java(input_clp):
    """Carga un archivo CLIPS y ejecuta sus reglas."""
    try:
        env = clips.Environment()
        env.load(input_clp)
        env.reset()
        env.run()
    except clips.CLIPSError as e:
        print(f"Error ejecutando CLIPS: {e}", file=sys.stderr)

if __name__ == "__main__":
    # Ruta fija al archivo `output.clp` en la carpeta `generated_files/`
    input_clp = os.path.join("generated_files", "output.clp")

    # Verificar si el archivo existe antes de proceder
    if not os.path.exists(input_clp):
        print(f"Archivo no encontrado: {input_clp}", file=sys.stderr)
    else:
        convert_clp_to_java(input_clp)
