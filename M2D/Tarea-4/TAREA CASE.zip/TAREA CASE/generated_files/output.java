// Java code for class Professor
public class Professor extends Person {
   / int salary;
   protected int staffNumber;
   private int yearsOfService;
   public int numberOfClasses;
}

// Java code for class Student
public class Student extends Person {
   public int studentNumber;
   public int averageMark;
   public  isEligibleToEnroll() {
      // method body
   }
   public  getSeminarsTaken() {
      // method body
   }
}

// Java code for class Address
public class Address {
   public str street;
   public str city;
   public str state;
   public int postalCode;
   public str country;
   private  validate() {
      // method body
   }
   private  outputAsLabel() {
      // method body
   }
}

// Java code for class Person
public class Person {
   public str name;
   public str phoneNumber;
   public str emailAddress;
   public  purchaseParkingPass() {
      // method body
   }
}

