const canvas = document.getElementById('umlCanvas');
const ctx = canvas.getContext('2d');
let selectedClass = null;
let offsetX, offsetY;
let selectedRelation = null;
let draggingRelation = false;
let startDragX, startDragY;

const classes = [];
const relations = [];

class UMLClass {
    constructor(name, x, y) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.width = 180;
        this.height = 70;
        this.attributes = [];
        this.methods = [];
    }

    draw() {
        // Dibujar el rectángulo de la clase
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(this.x, this.y, this.width, this.height);
        ctx.strokeStyle = "#000";
        ctx.strokeRect(this.x, this.y, this.width, this.height);

        // Dibujar el nombre de la clase
        ctx.fillStyle = "#000";
        ctx.font = "bold 14px Arial";
        ctx.fillText(this.name, this.x + 10, this.y + 15);

        // Dibujar línea bajo el nombre
        ctx.beginPath();
        ctx.moveTo(this.x, this.y + 20);
        ctx.lineTo(this.x + this.width, this.y + 20);
        ctx.stroke();

        // Dibujar atributos
        let yPosition = this.y + 35;
        ctx.font = "12px Arial";
        this.attributes.forEach((attr) => {
            ctx.fillText(attr, this.x + 10, yPosition);
            yPosition += 15;
        });

        // Dibujar línea bajo los atributos
        ctx.beginPath();
        ctx.moveTo(this.x, yPosition);
        ctx.lineTo(this.x + this.width, yPosition);
        ctx.stroke();

        // Dibujar métodos
        yPosition += 15;
        this.methods.forEach((meth) => {
            ctx.fillText(meth, this.x + 10, yPosition);
            yPosition += 15;
        });

        // Ajustar altura según contenido
        this.height = Math.max(70, yPosition - this.y + 10);
    }

    addAttribute(attr) {
        this.attributes.push(attr);
    }

    addMethod(method) {
        this.methods.push(method);
    }
}

class Relation {
    constructor(fromClass, toClass, type, fromMultiplicity, toMultiplicity) {
        this.fromClass = fromClass;
        this.toClass = toClass;
        this.type = type;
        this.fromMultiplicity = fromMultiplicity;
        this.toMultiplicity = toMultiplicity;
    }

    draw() {
        const { fromX, fromY, toX, toY } = calculateLinePoints(
            this.fromClass,
            this.toClass,
            0
        );

        // Dibujar línea de la relación
        ctx.beginPath();
        ctx.moveTo(fromX, fromY);
        ctx.lineTo(toX, toY);
        ctx.strokeStyle = "#000";
        ctx.stroke();

        // Ajustar las posiciones para que las multiplicidades queden fuera del cuadro
        const offsetMultiplier = -15; // Separación de las multiplicidades de la línea
        const angle = Math.atan2(toY - fromY, toX - fromX);

        // Multiplicidad en el extremo de origen
        const fromMultiplicityX = fromX - Math.cos(angle) * offsetMultiplier;
        const fromMultiplicityY = fromY - Math.sin(angle) * offsetMultiplier;
        ctx.fillStyle = "#000";
        ctx.font = "12px Arial";
        ctx.fillText(this.fromMultiplicity, fromMultiplicityX, fromMultiplicityY);

        // Multiplicidad en el extremo de destino
        const toMultiplicityX = toX + Math.cos(angle) * offsetMultiplier;
        const toMultiplicityY = toY + Math.sin(angle) * offsetMultiplier;
        ctx.fillText(this.toMultiplicity, toMultiplicityX, toMultiplicityY);
    }
}


function drawReflexiveArrow(cls, multiplicity) {
    const startX = cls.x + cls.width / 2;
    const startY = cls.y;
    const loopWidth = 40;
    const loopHeight = 50;

    ctx.beginPath();
    ctx.moveTo(startX, startY);
    ctx.lineTo(startX, startY - loopHeight);
    ctx.lineTo(startX - loopWidth, startY - loopHeight);
    ctx.lineTo(startX - loopWidth, startY);
    ctx.moveTo(startX,startY);
	
	const arrowWidth = 5;
    const arrowHeight = 10;
	

    ctx.lineTo(startX-arrowWidth,startY-arrowHeight);
    ctx.moveTo(startX, startY);
    ctx.lineTo(startX+arrowWidth,startY-arrowHeight);
  
    ctx.stroke();

    

    // Dibujar la multiplicidad cerca de la flecha
    ctx.font = '12px Arial';
    ctx.fillText(multiplicity, startX+7, startY -5);
}

function drawInheritanceArrow(toX, toY, fromX, fromY) {
    const headLength = 10;
    const angle = Math.atan2(toY - fromY, toX - fromX);

    ctx.beginPath();
    ctx.moveTo(toX, toY);
    ctx.lineTo(toX - headLength * Math.cos(angle - Math.PI / 6), toY - headLength * Math.sin(angle - Math.PI / 6));
    ctx.lineTo(toX - headLength * Math.cos(angle + Math.PI / 6), toY - headLength * Math.sin(angle + Math.PI / 6));
    ctx.closePath();
    ctx.fillStyle = 'white';
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = 'black';
}

function drawFlecha(fromX, fromY, toX, toY) {
    const arrowWidth = 10;
    const arrowHeight = 20;
    const angle = Math.atan2(toY - fromY, toX - fromX);

    ctx.save();

    ctx.translate(toX, toY);
    ctx.rotate(angle);

    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(-arrowWidth, -arrowHeight / 4);
    ctx.moveTo(0, 0);
    ctx.lineTo(-arrowWidth, arrowHeight / 4);
    ctx.closePath();
    ctx.stroke();
    ctx.restore();
}

function drawCompositionDiamond(fromX, fromY, toX, toY) {
    const diamondWidth = 10;
    const diamondHeight = 20;
    const angle = Math.atan2(toY - fromY, toX - fromX);

    ctx.save();
    ctx.translate(fromX, fromY);
    ctx.rotate(angle - Math.PI / 2);

    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(-diamondWidth / 2, diamondHeight / 2);
    ctx.lineTo(0, diamondHeight);
    ctx.lineTo(diamondWidth / 2, diamondHeight / 2);
    ctx.closePath();
    ctx.fillStyle = 'black';
    ctx.fill();
    ctx.restore();
}

function drawAgregationDiamond(fromX, fromY, toX, toY) {
    const diamondWidth = 10;
    const diamondHeight = 20;
    const angle = Math.atan2(toY - fromY, toX - fromX);

    ctx.save();
    ctx.translate(fromX, fromY);
    ctx.rotate(angle - Math.PI / 2);

    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(-diamondWidth / 2, diamondHeight / 2);
    ctx.lineTo(0, diamondHeight);
    ctx.lineTo(diamondWidth / 2, diamondHeight / 2);
    ctx.closePath();

    ctx.fillStyle = 'white';
    ctx.fill();

    ctx.strokeStyle = 'black';
    ctx.stroke();

    ctx.restore();
}

function addClass() {
    const className = document.getElementById('classNameInput').value;
    const newClass = new UMLClass(className, 50, 50);
    classes.push(newClass);
    updateClassSelects();
    drawDiagram();
}
// Eventos para gestionar cambios en los selects
document.getElementById('fromClassSelect').addEventListener('change', function () {
    const selectedClass = classes.find(c => c.name === this.value);
    if (selectedClass) {
        // Mostrar el nombre de la clase seleccionada
        document.getElementById('classNameInput').value = selectedClass.name;

        // Actualizar las listas de atributos y métodos
        updateAttributeList(selectedClass);
        updateMethodList(selectedClass);
    } else {
        // Vaciar las listas si no hay una clase seleccionada
        document.getElementById('attributeList').innerHTML = '';
        document.getElementById('methodList').innerHTML = '';
    }
});



document.getElementById('toClassSelect').addEventListener('change', function () {
    const selectedClass = classes.find(c => c.name === this.value);
    if (selectedClass) {
        // Mostrar el nombre de la clase seleccionada
        document.getElementById('classNameInput').value = selectedClass.name;

        // Actualizar la lista de atributos en el formulario
        updateAttributeList(selectedClass);
    }
});

function addAttribute() {
    const className = document.getElementById('classNameInput').value;
    const attribute = document.getElementById('attributeInput').value;
    const visibility = document.getElementById('attributeVisibility').value;
    const type = document.getElementById('attributeType').value;

    // Mapea visibilidad a su símbolo correspondiente
    const visibilityMap = {
        'public': '+',
        'private': '-',
        'protected': '#'
    };
    const symbol = visibilityMap[visibility] || visibility; // Usa el símbolo o el valor original como fallback

    // Construye el atributo con el formato correcto
    const attr = `${symbol} ${attribute}:${type}`;

    const cls = classes.find(c => c.name === className);
    if (cls) {
        cls.addAttribute(attr); // Añadir el atributo a la clase
		updateAttributeList(cls); // Actualizar la lista de atributos en el formulario
		updateMethodList(cls); // Actualizar la lista de métodos en el formulario
        drawDiagram(); // Redibujar el diagrama para reflejar los cambios
    }
}


function addMethod() {
    const className = document.getElementById('classNameInput').value;
    const method = document.getElementById('methodInput').value;
    const visibility = document.getElementById('methodVisibility').value;
    const type = document.getElementById('methodType').value;

    // Mapea visibilidad a su símbolo correspondiente
    const visibilityMap = {
        'public': '+',
        'private': '-',
        'protected': '#'
    };
    const symbol = visibilityMap[visibility] || visibility; // Usa el símbolo o el valor original como fallback

    // Construye el método con el formato correcto
    const meth = `${symbol} ${method}():${type}`;

    const cls = classes.find(c => c.name === className);
    if (cls) {
        cls.addMethod(meth); // Añadir el método a la clase
		updateMethodList(cls); // Actualizar la lista de métodos en el formulario
		updateAttributeList(cls); // Actualizar la lista de atributos en el formulario
        drawDiagram(); // Redibujar el diagrama para reflejar los cambios
    }
}


function addRelation() {
    const fromClass = document.getElementById('fromClassSelect').value;
    const toClass = document.getElementById('toClassSelect').value;
    const type = document.getElementById('relationType').value;
    const fromMultiplicity = document.getElementById('multiplicityFrom').value || '1';
    const toMultiplicity = document.getElementById('multiplicityTo').value || '*';

    const fromCls = classes.find(c => c.name === fromClass);
    const toCls = classes.find(c => c.name === toClass);

    if (fromCls && toCls) {
        const newRelation = new Relation(fromCls, toCls, type, fromMultiplicity, toMultiplicity);
        relations.push(newRelation);
        drawDiagram();
    }
}

function updateClassSelects() {
    const fromClassSelect = document.getElementById('fromClassSelect');
    const toClassSelect = document.getElementById('toClassSelect');

    fromClassSelect.innerHTML = '';
    toClassSelect.innerHTML = '';

    classes.forEach(cls => {
        const optionFrom = document.createElement('option');
        optionFrom.value = cls.name;
        optionFrom.text = cls.name;
        fromClassSelect.add(optionFrom);

        const optionTo = document.createElement('option');
        optionTo.value = cls.name;
        optionTo.text = cls.name;
        toClassSelect.add(optionTo);
    });
}

function drawDiagram() {
    ctx.clearRect(0, 0, canvas.width, canvas.height); // Limpiar el canvas

    // Dibujar relaciones primero
    relations.forEach((relation) => relation.draw());

    // Dibujar clases después
    classes.forEach((cls) => cls.draw());
}


function calculateLinePoints(fromClass, toClass, offset) {
    const fromXCenter = fromClass.x + fromClass.width / 2;
    const fromYCenter = fromClass.y + fromClass.height / 2;

    const toXCenter = toClass.x + toClass.width / 2;
    const toYCenter = toClass.y + toClass.height / 2;

    const dx = toXCenter - fromXCenter;
    const dy = toYCenter - fromYCenter;

    const length = Math.sqrt(dx * dx + dy * dy);
    const unitDx = dx / length;
    const unitDy = dy / length;

    const fromX = fromXCenter + unitDx * (fromClass.width / 2 + offset);
    const fromY = fromYCenter + unitDy * (fromClass.height / 2 + offset);

    const toX = toXCenter - unitDx * (toClass.width / 2 + offset);
    const toY = toYCenter - unitDy * (toClass.height / 2 + offset);

    return { fromX, fromY, toX, toY };
}

function intersectionWithLineSegment(x1, y1, x2, y2, x3, y3, x4, y4) {
    const ua = ((x4 - x3) * (y1 - y3) - (y4 - y3) * (x1 - x3)) / ((y4 - y3) * (x2 - x1) - (x4 - x3) * (y2 - y1));
    const ub = ((x2 - x1) * (y1 - y3) - (y2 - y1) * (x1 - x3)) / ((y4 - y3) * (x2 - x1) - (x4 - x3) * (y2 - y1));

    if (ua >= 0 && ua <= 1 && ub >= 0 && ub <= 1) {
        const intersectionX = x1 + ua * (x2 - x1);
        const intersectionY = y1 + ua * (y2 - y1);
        return { x: intersectionX, y: intersectionY };
    }
    return null;
}

function distance(x1, y1, x2, y2) {
    return Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);
}

canvas.addEventListener('mousedown', function (e) {
    const mouseX = e.offsetX;
    const mouseY = e.offsetY;

    // Detectar si el mouse está sobre una clase
    selectedClass = classes.find(
        (cls) =>
            mouseX >= cls.x &&
            mouseX <= cls.x + cls.width &&
            mouseY >= cls.y &&
            mouseY <= cls.y + cls.height
    );

    if (selectedClass) {
        // Calcular la diferencia entre la posición del mouse y la posición de la clase
        offsetX = mouseX - selectedClass.x;
        offsetY = mouseY - selectedClass.y;
    }
});

canvas.addEventListener('mousemove', function (e) {
    if (selectedClass) {
        // Actualizar la posición de la clase seleccionada
        selectedClass.x = e.offsetX - offsetX;
        selectedClass.y = e.offsetY - offsetY;

        // Redibujar el diagrama (clases y relaciones)
        drawDiagram();
    }
});

canvas.addEventListener('mouseup', function () {
    // Liberar la clase seleccionada
    selectedClass = null;
});


function escapeXML(value) {
    return value.replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function generateXMI() {
    let xmi = `<?xml version="1.0" encoding="UTF-8"?>\n`;
    xmi += `  <XMI xmi.version="2.1" xmlns:xmi="http://schema.omg.org/spec/XMI/2.1" xmlns:uml="http://www.omg.org/spec/UML/20090901">\n`;
    xmi += `  <uml:Model xmi:type="uml:Model" name="UMLModel">\n`;

    classes.forEach(cls => {
        xmi += `    <packagedElement xmi:type="uml:Class" name="${cls.name}">\n`;
        cls.attributes.forEach(attr => {
            const [visibility, rest] = attr.split(' ');
            const [name, type] = rest.split(':');
            const escapedType = type ? escapeXML(type.trim()) : '';
            console.log(`Attribute - Name: ${name}, Type: ${escapedType}`);
            xmi += `      <ownedAttribute visibility="${visibility}" name="${name.trim()}" type="${escapedType}" />\n`;
        });
        cls.methods.forEach(meth => {
            const [visibility, rest] = meth.split(' ');
            const [name, returnType] = rest.split(':');
            const escapedReturnType = returnType ? escapeXML(returnType.trim()) : '';
            console.log(`Method - Name: ${name}, ReturnType: ${escapedReturnType}`);
            xmi += `      <ownedOperation visibility="${visibility}" name="${name.replace('()', '').trim()}" type="${escapedReturnType}" />\n`;
        });
        xmi += `    </packagedElement>\n`;
    });

    relations.forEach(rel => {
        let relationType = 'Association';
        if (rel.type === 'herencia') {
            relationType = 'Generalization';
        } else if (rel.type === 'composición') {
            relationType = 'Composition';
        } else if (rel.type === 'agregación') {
            relationType = 'Aggregation';
        } else if (rel.type === 'dependencia') {
            relationType = 'Dependency';
        } else if (rel.type === 'asociaciónDireccional') {
            relationType = 'DirectedAssociation';
        }

        xmi += `    <packagedElement xmi:type="uml:${relationType}" memberEnd="${rel.fromClass.name} ${rel.toClass.name}">\n`;
        if ((relationType !== 'Generalization') &&  (relationType !== 'Dependency')) {
            xmi += `      <ownedEnd type="${rel.fromClass.name}" multiplicity1="${rel.fromMultiplicity}" />\n`;
            xmi += `      <ownedEnd type="${rel.toClass.name}" multiplicity2="${rel.toMultiplicity}" />\n`;
        }
        xmi += `    </packagedElement>\n`;
    });

    xmi += `  </uml:Model>\n</XMI>`;
    return xmi;
}

function downloadXMI() {
    const xmi = generateXMI();
    const blob = new Blob([xmi], { type: 'application/xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'diagram.xmi';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}

function downloadCustomXMI() {
    const xmi = generateXMI();
    fetch('/download-xmi', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ xmi: xmi })
    })
    .then(response => response.blob())
    .then(blob => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'diagram.xmi';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
    })
    .catch(error => console.error('Error:', error));
}

function saveJAVAtoServer() {
    const xmi = generateXMI();
    fetch('/save-xmi', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/xml',
        },
        body: xmi
    })
    .then(response => {
        if (response.ok) {
            return response.blob();
        }
        throw new Error('Network response was not ok');
    })
    .then(blob => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'output.java';
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error processing and downloading Java file');
    });
}

// Se procesa el contenido del .XML para dibujar las clases, atributos, métodos y relaciones.
function loadXMI() {
    const input = document.getElementById('uploadXMI');
    const file = input.files[0];

    if (!file) {
        alert("Por favor, selecciona un archivo XMI.");
        return;
    }

    const reader = new FileReader();

    reader.onload = function (event) {
        const xmiContent = event.target.result;

        try {
            // Analizar el archivo XMI como XML
            const parser = new DOMParser();
            const xmlDoc = parser.parseFromString(xmiContent, "application/xml");

            // Llamar a la función para procesar y dibujar el contenido del XMI
            parseAndDrawXMI(xmlDoc);
			// Redibujar el canvas para reflejar los cambios
			drawDiagram();

        } catch (error) {
            console.error("Error al procesar el archivo XMI:", error);
            alert("Hubo un error al cargar el archivo XMI.");
        }
    };

    reader.readAsText(file);
}

// Función para procesar y dibujar el contenido del XMI
function parseAndDrawXMI(xmlDoc) {
    // Limpiar el canvas y arrays
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    classes.length = 0; // Limpiar clases existentes
    relations.length = 0; // Limpiar relaciones existentes

    let x = 50; // Coordenadas iniciales para las clases
    let y = 50;
    const classPositions = {}; // Guardar las posiciones de las clases por nombre

    const classSelect = document.getElementById('fromClassSelect');
    const toClassSelect = document.getElementById('toClassSelect');

    // Vaciar selects para las clases
    classSelect.innerHTML = '';
    toClassSelect.innerHTML = '';

    // === Procesar clases ===
    const packagedElements = xmlDoc.getElementsByTagName("packagedElement");
    for (const cls of packagedElements) {
        if (cls.getAttribute("xmi:type") === "uml:Class") {
            const className = cls.getAttribute("name") || "Clase sin nombre";

            // Extraer atributos
            const attributes = [];
            const ownedAttributes = cls.getElementsByTagName("ownedAttribute");
            for (const attr of ownedAttributes) {
                const attrName = attr.getAttribute("name") || "Atributo sin nombre";
                const attrType = attr.getAttribute("type") || "String";
                const visibility = attr.getAttribute("visibility") || "+";
                attributes.push(`${visibility} ${attrName}:${attrType}`);
            }
			
            // Extraer métodos
            const methods = [];
            const ownedOperations = cls.getElementsByTagName("ownedOperation");
            for (const op of ownedOperations) {
                const opName = op.getAttribute("name") || "Método sin nombre";
                const visibility = op.getAttribute("visibility") || "+";
                methods.push(`${visibility} ${opName}()`);
            }

            // Crear la clase y añadirla al array global `classes`
            const umlClass = new UMLClass(className, x, y);
            umlClass.attributes = attributes;
            umlClass.methods = methods;
            classes.push(umlClass);

            // Añadir la clase a los selects del formulario
            const optionFrom = document.createElement('option');
            optionFrom.value = className;
            optionFrom.text = className;
            classSelect.add(optionFrom);

            const optionTo = document.createElement('option');
            optionTo.value = className;
            optionTo.text = className;
            toClassSelect.add(optionTo);

            // Guardar posición de la clase usando el nombre como identificador
            classPositions[className] = umlClass;

            // Actualizar posición
            x += 200;
            if (x > canvas.width - 200) {
                x = 50;
                y += 150;
            }
        }
    }

    // === Procesar relaciones ===
    for (const assoc of packagedElements) {
        if (assoc.getAttribute("xmi:type") === "uml:Association") {
            const memberEnd = assoc.getAttribute("memberEnd");

            if (memberEnd) {
                const [sourceName, targetName] = memberEnd.split(" ");
                const sourceClass = classPositions[sourceName];
                const targetClass = classPositions[targetName];

                if (sourceClass && targetClass) {
                    const sourceMultiplicity = assoc.getAttribute("sourceMultiplicity") || "1";
                    const targetMultiplicity = assoc.getAttribute("targetMultiplicity") || "*";

                    // Crear la relación y añadirla al array global `relations`
                    const relation = new Relation(
                        sourceClass,
                        targetClass,
                        "Association",
                        sourceMultiplicity,
                        targetMultiplicity
                    );
                    relations.push(relation);
                }
            }
        }
    }

    // Redibujar el diagrama
    drawDiagram();

    // Actualizar formulario con la primera clase y relación (opcional)
    if (classes.length > 0) {
		const firstClass = classes[0];
        document.getElementById('classNameInput').value = classes[0].name;
		updateAttributeList(firstClass);
		updateMethodList(firstClass);
        if (classes[0].attributes.length > 0) {
            document.getElementById('attributeInput').value = classes[0].attributes[0].split(':')[0].split(' ')[1]; // Nombre atributo
            document.getElementById('attributeType').value = classes[0].attributes[0].split(':')[1]; // Tipo atributo
        }
        if (classes[0].methods.length > 0) {
            document.getElementById('methodInput').value = classes[0].methods[0].split(':')[0].split(' ')[1]; // Nombre método
            document.getElementById('methodType').value = classes[0].methods[0].split(':')[1]; // Tipo método
        }
    }

    if (relations.length > 0) {
        document.getElementById('relationType').value = relations[0].type;
        document.getElementById('multiplicityFrom').value = relations[0].fromMultiplicity;
        document.getElementById('multiplicityTo').value = relations[0].toMultiplicity;
    }
}

// Función para dibujar clases
function drawClassOnCanvas(ctx, className, attributes, operations, x, y) {
    const width = 150;
    const attributeHeight = attributes.length * 20;
    const operationHeight = operations.length * 20;
    const totalHeight = 40 + attributeHeight + operationHeight;

    // Dibujar el rectángulo de la clase
    ctx.fillStyle = "#f0f0f0";
    ctx.fillRect(x, y, width, totalHeight);
    ctx.strokeStyle = "#000";
    ctx.strokeRect(x, y, width, totalHeight);

    // Dibujar el nombre de la clase
    ctx.fillStyle = "#000";
    ctx.font = "bold 14px Arial";
    ctx.textAlign = "center";
    ctx.fillText(className, x + width / 2, y + 20);

    // Dibujar los atributos
    let currentY = y + 40;
    ctx.textAlign = "left";
    ctx.font = "12px Arial";
    for (const attr of attributes) {
        ctx.fillText(attr, x + 10, currentY);
        currentY += 20;
    }

    // Dibujar una línea separadora entre atributos y métodos
    ctx.beginPath();
    ctx.moveTo(x, currentY);
    ctx.lineTo(x + width, currentY);
    ctx.stroke();

    // Dibujar los métodos
    currentY += 10;
    for (const op of operations) {
        ctx.fillText(op, x + 10, currentY);
        currentY += 20;
    }
}


// Función para dibujar relaciones
function drawRelationshipOnCanvas(ctx, source, target, sourceMultiplicity, targetMultiplicity) {
    // Determinar los bordes de las clases para conectar la línea correctamente
    const startX = source.x + source.width / 2; // Centro horizontal de la clase de origen
    const startY = source.y + source.height / 2; // Centro vertical de la clase de origen
    const endX = target.x + target.width / 2; // Centro horizontal de la clase de destino
    const endY = target.y + target.height / 2; // Centro vertical de la clase de destino

    // Dibujar la línea de la relación
    ctx.beginPath();
    ctx.moveTo(startX, startY);
    ctx.lineTo(endX, endY);
    ctx.strokeStyle = "#000";
    ctx.stroke();

    // Dibujar multiplicidades cerca de los extremos
    if (sourceMultiplicity) {
        ctx.font = "12px Arial";
        ctx.fillStyle = "#000";
        ctx.fillText(sourceMultiplicity, startX - 20, startY - 10);
    }

    if (targetMultiplicity) {
        ctx.font = "12px Arial";
        ctx.fillStyle = "#000";
        ctx.fillText(targetMultiplicity, endX + 10, endY + 10);
    }
}

// Eliminacion de atributo
function removeClassAttribute() {
    const className = document.getElementById('classNameInput').value; // Clase seleccionada
    const attributeSelect = document.getElementById('attributeList'); // Select de atributos
    const selectedAttribute = attributeSelect.value; // Atributo seleccionado

    // Buscar la clase correspondiente
    const cls = classes.find(c => c.name === className);
    if (cls && selectedAttribute) {
        // Eliminar el atributo de la lista de atributos de la clase
        cls.attributes = cls.attributes.filter(attr => attr !== selectedAttribute);

        // Actualizar la lista de atributos en el formulario
        updateAttributeList(cls);

        // Redibujar el diagrama
        drawDiagram();
    } else {
        alert('Selecciona un atributo válido para eliminar.');
    }
}

function updateAttributeList(cls) {
    const attributeSelect = document.getElementById('attributeList');
    attributeSelect.innerHTML = ''; // Vaciar la lista actual

    if (cls && cls.attributes.length > 0) {
        cls.attributes.forEach(attr => {
            const option = document.createElement('option');
            option.value = attr; // El valor será el nombre completo del atributo
            option.text = attr; // El texto visible en el select
            attributeSelect.add(option);
        });
    } else {
        const placeholderOption = document.createElement('option');
        placeholderOption.text = 'Sin atributos disponibles';
        placeholderOption.disabled = true;
        attributeSelect.add(placeholderOption);
    }
}

// Eliminar Método de una Clase
function removeClassMethod() {
    const className = document.getElementById('classNameInput').value; // Obtener la clase seleccionada
    const methodSelect = document.getElementById('methodList'); // Referencia al select de métodos
    const selectedMethod = methodSelect.value; // Método seleccionado

    // Buscar la clase correspondiente
    const cls = classes.find(c => c.name === className);
    if (cls && selectedMethod) {
        // Eliminar el método de la clase
        cls.methods = cls.methods.filter(method => method !== selectedMethod);

        // Actualizar la lista de métodos en el formulario
        updateMethodList(cls);

        // Redibujar el diagrama
        drawDiagram();
    } else {
        alert('Selecciona un método válido para eliminar.');
    }
}

function updateMethodList(cls) {
    const methodSelect = document.getElementById('methodList');
    methodSelect.innerHTML = ''; // Vaciar el select actual

    if (cls && cls.methods.length > 0) {
        cls.methods.forEach(method => {
            const option = document.createElement('option');
            option.value = method; // El valor será el nombre completo del método
            option.text = method; // El texto que se muestra en la lista
            methodSelect.add(option);
        });
    } else {
        const placeholderOption = document.createElement('option');
        placeholderOption.text = 'Sin métodos disponibles';
        placeholderOption.disabled = true;
        methodSelect.add(placeholderOption);
    }
}


// Elimina una Clase
function removeClass() {
    const className = document.getElementById('classNameInput').value;

    // Verificar si la clase existe antes de continuar
    const classIndex = classes.findIndex(cls => cls.name === className);

    if (classIndex === -1) {
        alert("Clase no encontrada para eliminar.");
        return;
    }

    // Mostrar mensaje de confirmación
    const confirmation = confirm(`¿Estás seguro de que deseas eliminar la clase "${className}"? Esto también eliminará todas sus relaciones asociadas.`);
    
    if (!confirmation) {
        return; // Si el usuario cancela, salir de la función
    }

    // Eliminar la clase del array de clases
    const removedClass = classes.splice(classIndex, 1)[0];

    // Filtrar y eliminar relaciones asociadas a la clase eliminada
    for (let i = relations.length - 1; i >= 0; i--) {
        if (relations[i].fromClass === removedClass || relations[i].toClass === removedClass) {
            relations.splice(i, 1); // Eliminar la relación del array
        }
    }

    // Actualizar los selects de clases
    updateClassSelects();

    // Redibujar el canvas para reflejar los cambios
    drawDiagram();
}
