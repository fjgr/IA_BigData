import torch
import numpy as np
import joblib
from fastapi import FastAPI, HTTPException, status, Query
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from datetime import datetime, date, timedelta
import uvicorn
import os
import sys
import warnings
import subprocess
import re
import csv
from contextlib import asynccontextmanager

# Importar directamente requests para asegurar que está disponible
try:
    import requests
except ImportError:
    print("ERROR: El módulo 'requests' no está instalado. Por favor, instálelo con: pip install requests")

warnings.filterwarnings("ignore", category=UserWarning, module="sklearn.utils.validation")
# Definir la estructura del modelo de red neuronal concurrente original
class ConcurrentNeuralNetwork(torch.nn.Module):
    def __init__(self, dropout_rate=0.2):
        super(ConcurrentNeuralNetwork, self).__init__()
        
        # Subred para la zona norte (temperatura y humedad)
        self.norte_subnet = torch.nn.Sequential(
            torch.nn.Linear(2, 16),
            torch.nn.ReLU(),
            torch.nn.Dropout(dropout_rate),
            torch.nn.Linear(16, 8),
            torch.nn.ReLU()
        )
        
        # Subred para la zona este (temperatura y humedad)
        self.este_subnet = torch.nn.Sequential(
            torch.nn.Linear(2, 16),
            torch.nn.ReLU(),
            torch.nn.Dropout(dropout_rate),
            torch.nn.Linear(16, 8),
            torch.nn.ReLU()
        )
        
        # Subred para la zona sur (temperatura y humedad)
        self.sur_subnet = torch.nn.Sequential(
            torch.nn.Linear(2, 16),
            torch.nn.ReLU(),
            torch.nn.Dropout(dropout_rate),
            torch.nn.Linear(16, 8),
            torch.nn.ReLU()
        )
        
        # Subred para variables temporales
        self.temporal_subnet = torch.nn.Sequential(
            torch.nn.Linear(5, 16),
            torch.nn.ReLU(),
            torch.nn.Dropout(dropout_rate),
            torch.nn.Linear(16, 8),
            torch.nn.ReLU()
        )
        
        # Subred para consumo por zonas
        self.consumo_subnet = torch.nn.Sequential(
            torch.nn.Linear(4, 16),
            torch.nn.ReLU(),
            torch.nn.Dropout(dropout_rate),
            torch.nn.Linear(16, 8),
            torch.nn.ReLU()
        )
        
        # Red de integración
        self.integration_net = torch.nn.Sequential(
            torch.nn.Linear(40, 32),
            torch.nn.ReLU(),
            torch.nn.Dropout(dropout_rate),
            torch.nn.Linear(32, 16),
            torch.nn.ReLU(),
            torch.nn.Dropout(dropout_rate),
            torch.nn.Linear(16, 1)
        )
        
    def forward(self, x):
        # Extraer las características para cada subred
        temp_hum_norte = x[:, [0, 3]]  # temp_norte, hum_norte
        temp_hum_este = x[:, [1, 4]]   # temp_este, hum_este
        temp_hum_sur = x[:, [2, 5]]    # temp_sur, hum_sur
        temporal = x[:, 6:11]          # mes_sin, mes_cos, dia_año_sin, dia_año_cos, es_fin_semana
        consumo_zonas = x[:, 11:15]    # consumo_zona_norte, consumo_zona_este, consumo_zona_sur, consumo_zona_resto
        
        # Procesar cada conjunto de características
        norte_out = self.norte_subnet(temp_hum_norte)
        este_out = self.este_subnet(temp_hum_este)
        sur_out = self.sur_subnet(temp_hum_sur)
        temporal_out = self.temporal_subnet(temporal)
        consumo_out = self.consumo_subnet(consumo_zonas)
        
        # Concatenar las salidas
        combined = torch.cat([norte_out, este_out, sur_out, temporal_out, consumo_out], dim=1)
        
        # Procesar a través de la red de integración
        output = self.integration_net(combined)
        
        return output.squeeze()

# Definir los modelos de datos para la API
class PredictionInput(BaseModel):
    fecha: str
    temp_norte: float
    temp_este: float
    temp_sur: float
    hum_norte: float
    hum_este: float
    hum_sur: float

class ZonalConsumption(BaseModel):
    consumo_zona_norte: float
    consumo_zona_este: float
    consumo_zona_sur: float
    consumo_zona_resto: float
    consumo_total: float

class PredictionOutput(BaseModel):
    fecha: str
    predicciones: ZonalConsumption

class BatchPredictionInput(BaseModel):
    predicciones: List[PredictionInput]

class BatchPredictionOutput(BaseModel):
    predicciones: List[PredictionOutput]

# Variables globales para el modelo y los escaladores
model = None
scaler_meteo_temp = None
scaler_consumo = None
scaler_target = None

# Definir rutas de directorios
BASE_DIR = os.path.dirname(os.path.abspath(__file__))  # C:\Proyecto\src
DATA_DIR = os.path.join(BASE_DIR, "data")  # C:\Proyecto\src\data

# Asegurar que el directorio data existe
os.makedirs(DATA_DIR, exist_ok=True)

# Definir el gestor de ciclo de vida para cargar el modelo al inicio
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Código que se ejecuta al iniciar la aplicación
    global model, scaler_meteo_temp, scaler_consumo, scaler_target
    
    # Definir rutas relativas a la ubicación del script
    models_dir = os.path.join(os.path.dirname(BASE_DIR), "models")
    
    try:
        # Cargar escaladores
        scaler_meteo_temp = joblib.load(os.path.join(models_dir, "scaler_meteo_temp.pkl"))
        scaler_consumo = joblib.load(os.path.join(models_dir, "scaler_consumo.pkl"))
        scaler_target = joblib.load(os.path.join(models_dir, "scaler_target.pkl"))
        
        # Cargar modelo
        model = ConcurrentNeuralNetwork()
        model.load_state_dict(torch.load(os.path.join(models_dir, "MultiBranch_nn_model.pth"), map_location=torch.device('cpu')))
        model.eval()
        
        print("Modelo y escaladores cargados correctamente.")
    except Exception as e:
        print(f"Error al cargar el modelo o los escaladores: {e}")
        raise e
    
    yield  # Aquí la aplicación está en funcionamiento
    
    # Código que se ejecuta al detener la aplicación
    # Limpieza de recursos si es necesario
    print("Liberando recursos...")

# Crear la aplicación FastAPI con el gestor de ciclo de vida
app = FastAPI(
    title="API de Predicción de Consumo Energético en Gran Canaria",
    description="API para predecir el consumo energético por zonas y total de Gran Canaria utilizando variables meteorológicas.",
    version="1.6.0",
    lifespan=lifespan
)

# Configurar CORS para permitir solicitudes desde el frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # En producción, esto debería limitarse a orígenes específicos
    allow_credentials=True,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)

@app.get("/health", status_code=status.HTTP_200_OK)
async def health_check():
    """
    Health‐check rápido: devuelve 200 OK si el servidor está vivo.
    """
    return {"status": "ok"}

# Función para preprocesar los datos de entrada
def preprocess_input(input_data):
    # Extraer fecha
    fecha = datetime.strptime(input_data.fecha, "%Y-%m-%d")
    
    # Crear características temporales
    mes = fecha.month
    dia_año = fecha.timetuple().tm_yday
    dia_semana = fecha.weekday()
    es_fin_semana = 1 if dia_semana >= 5 else 0
    
    # Crear variables cíclicas
    mes_sin = np.sin(2 * np.pi * mes / 12)
    mes_cos = np.cos(2 * np.pi * mes / 12)
    dia_año_sin = np.sin(2 * np.pi * dia_año / 365)
    dia_año_cos = np.cos(2 * np.pi * dia_año / 365)
    
    # Preparar datos meteorológicos y temporales para normalización
    meteo_temp_data = np.array([
        input_data.temp_norte, input_data.temp_este, input_data.temp_sur,
        input_data.hum_norte, input_data.hum_este, input_data.hum_sur,
        mes_sin, mes_cos, dia_año_sin, dia_año_cos, es_fin_semana
    ]).reshape(1, -1)
    
    # Normalizar los datos meteorológicos y temporales
    meteo_temp_scaled = scaler_meteo_temp.transform(meteo_temp_data)
    
    # Estimar consumos por zonas basados en datos meteorológicos
    # Estos valores son estimaciones iniciales que serán refinadas por el modelo
    estimated_consumo_norte = 3000 + 50 * (input_data.temp_norte - 20)
    estimated_consumo_este = 2000 + 40 * (input_data.temp_este - 20)
    estimated_consumo_sur = 2500 + 45 * (input_data.temp_sur - 20)
    estimated_consumo_resto = 1000 + 20 * ((input_data.temp_norte + input_data.temp_este + input_data.temp_sur) / 3 - 20)
    
    # Preparar datos de consumo por zonas para normalización
    consumo_data = np.array([
        estimated_consumo_norte, estimated_consumo_este, 
        estimated_consumo_sur, estimated_consumo_resto
    ]).reshape(1, -1)
    
    # Normalizar los datos de consumo
    consumo_scaled = scaler_consumo.transform(consumo_data)
    
    # Combinar los datos normalizados
    X_scaled = np.concatenate([meteo_temp_scaled, consumo_scaled], axis=1)
    
    return X_scaled, fecha, [estimated_consumo_norte, estimated_consumo_este, estimated_consumo_sur, estimated_consumo_resto]

# Endpoint para opciones CORS
@app.options("/predict")
async def options_predict():
    return JSONResponse(content={})

# Endpoint para predicción individual
@app.post("/predict", response_model=PredictionOutput)
async def predict(input_data: PredictionInput):
    try:
        # Preprocesar los datos de entrada
        X_scaled, fecha, estimated_consumos = preprocess_input(input_data)
        
        # Convertir a tensor de PyTorch
        X_tensor = torch.tensor(X_scaled, dtype=torch.float32)
        
        # Realizar predicción del consumo total
        with torch.no_grad():
            prediction_scaled = model(X_tensor)
        
        # Desnormalizar la predicción del consumo total
        consumo_total = float(scaler_target.inverse_transform(prediction_scaled.reshape(-1, 1)).flatten()[0])
        
        # Calcular los consumos por zonas basados en la proporción de las estimaciones iniciales
        total_estimated = sum(estimated_consumos)
        if total_estimated > 0:
            proportions = [x / total_estimated for x in estimated_consumos]
        else:
            proportions = [0.4, 0.25, 0.25, 0.1]  # Proporciones por defecto
        
        consumo_zona_norte = consumo_total * proportions[0]
        consumo_zona_este = consumo_total * proportions[1]
        consumo_zona_sur = consumo_total * proportions[2]
        consumo_zona_resto = consumo_total * proportions[3]
        
        return PredictionOutput(
            fecha=input_data.fecha,
            predicciones=ZonalConsumption(
                consumo_zona_norte=consumo_zona_norte,
                consumo_zona_este=consumo_zona_este,
                consumo_zona_sur=consumo_zona_sur,
                consumo_zona_resto=consumo_zona_resto,
                consumo_total=consumo_total
            )
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Endpoint para opciones CORS para batch
@app.options("/predict/batch")
async def options_predict_batch():
    return JSONResponse(content={})

# Endpoint para predicciones por lotes
@app.post("/predict/batch", response_model=BatchPredictionOutput)
async def predict_batch(input_data: BatchPredictionInput):
    try:
        results = []
        
        for item in input_data.predicciones:
            # Preprocesar los datos de entrada
            X_scaled, fecha, estimated_consumos = preprocess_input(item)
            
            # Convertir a tensor de PyTorch
            X_tensor = torch.tensor(X_scaled, dtype=torch.float32)
            
            # Realizar predicción
            with torch.no_grad():
                prediction_scaled = model(X_tensor)
            
            # Desnormalizar la predicción
            consumo_total = float(scaler_target.inverse_transform(prediction_scaled.reshape(-1, 1)).flatten()[0])
            
            # Calcular los consumos por zonas basados en la proporción de las estimaciones iniciales
            total_estimated = sum(estimated_consumos)
            if total_estimated > 0:
                proportions = [x / total_estimated for x in estimated_consumos]
            else:
                proportions = [0.4, 0.25, 0.25, 0.1]  # Proporciones por defecto
            
            consumo_zona_norte = consumo_total * proportions[0]
            consumo_zona_este = consumo_total * proportions[1]
            consumo_zona_sur = consumo_total * proportions[2]
            consumo_zona_resto = consumo_total * proportions[3]
            
            results.append(PredictionOutput(
                fecha=item.fecha,
                predicciones=ZonalConsumption(
                    consumo_zona_norte=consumo_zona_norte,
                    consumo_zona_este=consumo_zona_este,
                    consumo_zona_sur=consumo_zona_sur,
                    consumo_zona_resto=consumo_zona_resto,
                    consumo_total=consumo_total
                )
            ))
        
        return BatchPredictionOutput(predicciones=results)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Endpoint para información sobre el modelo
@app.get("/info")
async def model_info():
    return {
        "nombre": "Modelo de Red Neuronal Concurrente para Predicción de Consumo Energético",
        "version": "1.6.0",
        "descripcion": "Modelo que predice el consumo energético por zonas y total de Gran Canaria utilizando variables meteorológicas.",
        "variables_entrada": [
            "fecha", "temp_norte", "temp_este", "temp_sur", "hum_norte", "hum_este", "hum_sur"
        ],
        "variables_salida": [
            "consumo_zona_norte", "consumo_zona_este", "consumo_zona_sur", "consumo_zona_resto", "consumo_total"
        ]
    }

# Nuevo endpoint para obtener consumo diario de REE
@app.get("/consdia")
async def consumo_diario(fecha: str = Query(..., description="Fecha en formato YYYYMMDD")):
    try:
        # Validar formato de fecha
        if not re.match(r'^\d{8}$', fecha):
            raise HTTPException(
                status_code=400, 
                detail="Formato de fecha incorrecto. Debe ser YYYYMMDD (ej: 20250522)"
            )
        
        # Convertir formato YYYYMMDD a YYYY-MM-DD
        fecha_formateada = f"{fecha[:4]}-{fecha[4:6]}-{fecha[6:8]}"
        
        # Validar que la fecha no sea futura
        fecha_consulta = datetime.strptime(fecha_formateada, "%Y-%m-%d").date()
        hoy = date.today()
        
        if fecha_consulta != hoy:
            raise HTTPException(
                status_code=400, 
                detail=f"Sólo se permiten consultas para la fecha de hoy ({hoy.strftime('%Y%m%d')})"
            )
        
        # Ejecutar el script consumo_dia_ree.py con la fecha formateada
        try:
            # Ruta al intérprete de Python del entorno virtual
            python_venv = "C:\\Proyecto\\vProyecto\\Scripts\\python.exe"
            
            resultado = subprocess.run(
                [python_venv, "consumo_dia_ree.py", fecha_formateada],
                capture_output=True,
                text=True,
                check=True,
                cwd=BASE_DIR  # Ejecutar en el directorio src
            )
            
            # Procesar la salida para extraer los valores R y P
            salida = resultado.stdout.strip()
            
            # Usar expresión regular para extraer los valores
            match = re.search(r'R:\s*(\d+),\s*P:\s*(\d+)', salida)
            
            if match:
                real = int(match.group(1))
                previsto = int(match.group(2))
                
                # Devolver los valores en formato JSON
                return {"real": real, "previsto": previsto}
            else:
                raise HTTPException(
                    status_code=500, 
                    detail="No se pudieron extraer los valores de consumo de la salida del script"
                )
                
        except subprocess.CalledProcessError as e:
            raise HTTPException(
                status_code=500, 
                detail=f"Error al ejecutar el script: {e.stderr}"
            )
            
    except Exception as e:
        if isinstance(e, HTTPException):
            raise e
        else:
            raise HTTPException(
                status_code=500, 
                detail=f"Error inesperado: {str(e)}"
            )

# Endpoint para obtener temperatura diaria
@app.get("/tempdia")
async def temperatura_diaria(fecha: Optional[str] = Query(None, description="Fecha en formato YYYYMMDD (opcional, por defecto usa la fecha actual)")):
    try:
        # Si no se proporciona fecha, usar la fecha actual
        if fecha is None:
            fecha = datetime.now().strftime("%Y%m%d")
        
        # Validar formato de fecha
        if not re.match(r'^\d{8}$', fecha):
            raise HTTPException(
                status_code=400, 
                detail="Formato de fecha incorrecto. Debe ser YYYYMMDD (ej: 20250522)"
            )
        
        # Convertir formato YYYYMMDD a YYYY-MM-DD
        fecha_formateada = f"{fecha[:4]}-{fecha[4:6]}-{fecha[6:8]}"
        
        # Validar que la fecha no sea futura
        fecha_consulta = datetime.strptime(fecha_formateada, "%Y-%m-%d").date()
        hoy = date.today()
        
        if fecha_consulta != hoy:
            raise HTTPException(
                status_code=400, 
                detail=f"Sólo se permiten consultas para la fecha de hoy ({hoy.strftime('%Y%m%d')})"
            )
        
        # Nombre del archivo CSV que debería existir
        csv_filename = os.path.join(DATA_DIR, f"temp_dia{fecha}.csv")
        
        # Verificar si el archivo ya existe
        if not os.path.exists(csv_filename):
            # El archivo no existe
            # Verificar si la variable de entorno AEMET_API_KEY está definida
            if not os.getenv("AEMET_API_KEY"):
                raise HTTPException(
                    status_code=500,
                    detail="La variable de entorno AEMET_API_KEY no está definida. Es necesaria para ejecutar el script info-tiempo.py"
                )
            
            # Ejecutar el script info-tiempo.py con la fecha formateada
            try:
                # Ruta al intérprete de Python del entorno virtual
                python_venv = "C:\\Proyecto\\vProyecto\\Scripts\\python.exe"
                
                # Crear un entorno modificado con la variable DATA_DIR
                env_vars = dict(os.environ)
                env_vars["DATA_DIR"] = DATA_DIR
                
                resultado = subprocess.run(
                    [python_venv, "info-tiempo.py", fecha_formateada],
                    capture_output=True,
                    text=True,
                    check=True,
                    cwd=BASE_DIR,  # Ejecutar en el directorio src
                    env=env_vars  # Pasar las variables de entorno modificadas
                )
                
                # Verificar que el archivo se haya creado después de ejecutar el script
                if not os.path.exists(csv_filename):
                    raise HTTPException(
                        status_code=500,
                        detail=f"El script se ejecutó correctamente pero no se encontró el archivo {csv_filename}"
                    )
                    
            except subprocess.CalledProcessError as e:
                # Analizar el error para dar un mensaje más específico
                error_msg = e.stderr
                raise HTTPException(
                    status_code=500,
                    detail=f"Error al ejecutar el script: {error_msg}"
                )
        
        # Leer el archivo CSV
        try:
            with open(csv_filename, 'r', encoding='utf-8') as csvfile:
                reader = csv.DictReader(csvfile)
                for row in reader:
                    # Convertir valores a float, manejando posibles valores vacíos
                    temp_norte = float(row['temp_norte']) if row['temp_norte'] else None
                    temp_este = float(row['temp_este']) if row['temp_este'] else None
                    temp_sur = float(row['temp_sur']) if row['temp_sur'] else None
                    hum_norte = float(row['hum_norte']) if row['hum_norte'] else None
                    hum_este = float(row['hum_este']) if row['hum_este'] else None
                    hum_sur = float(row['hum_sur']) if row['hum_sur'] else None
                    
                    # Devolver los valores en formato JSON
                    return {
                        "temp_norte": temp_norte,
                        "temp_este": temp_este,
                        "temp_sur": temp_sur,
                        "hum_norte": hum_norte,
                        "hum_este": hum_este,
                        "hum_sur": hum_sur
                    }
                
                # Si no se encontró ninguna fila en el CSV
                raise HTTPException(
                    status_code=500,
                    detail=f"El archivo {csv_filename} está vacío o no contiene datos válidos"
                )
                
        except Exception as e:
            raise HTTPException(
                status_code=500,
                detail=f"Error al leer el archivo CSV: {str(e)}"
            )
            
    except Exception as e:
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail=str(e))

# Endpoint para obtener predicción de tiempo
# Nuevo endpoint para obtener predicciones meteorológicas
@app.get("/predtiempo")
async def prediccion_tiempo(fecha: Optional[str] = None):
    try:
        # Fecha actual en formato YYYYMMDD para verificar archivos
        fecha_actual = datetime.now().strftime("%Y%m%d")
        
        # Nombres de los archivos CSV que deberían existir
        csv_norte = os.path.join(DATA_DIR, f"gran_canaria_norte-{fecha_actual}.csv")
        csv_este = os.path.join(DATA_DIR, f"gran_canaria_este-{fecha_actual}.csv")
        csv_sur = os.path.join(DATA_DIR, f"gran_canaria_sur-{fecha_actual}.csv")
        
        # Verificar si los archivos ya existen
        archivos_existen = os.path.exists(csv_norte) and os.path.exists(csv_este) and os.path.exists(csv_sur)
        
        if not archivos_existen:
            # Los archivos no existen
            # Verificar si la variable de entorno AEMET_API_KEY está definida
            if not os.getenv("AEMET_API_KEY"):
                raise HTTPException(
                    status_code=500,
                    detail="La variable de entorno AEMET_API_KEY no está definida. Es necesaria para ejecutar el script pred_tiempo.py"
                )
            
            # Ejecutar directamente el código de pred_tiempo.py en lugar de llamar al script
            try:
                # Importar el módulo requests (debería estar disponible en el entorno virtual)
                import requests
                import time
                
                # Definición de zonas: nombre → lista de códigos de municipio
                ZONAS = {
                    "Gran_Canaria Norte": [
                        "35016",  # Las Palmas de Gran Canaria
                        "35004",  # Arucas
                        "35022",  # Gáldar
                    ],
                    "Gran_Canaria Este": [
                        "35035",  # Telde
                        "35012",  # Ingenio
                        "35005",  # Agüimes
                    ],
                    "Gran_Canaria Sur": [
                        "35037",  # San Bartolomé de Tirajana
                        "35036",  # Santa Lucía de Tirajana
                        "35018",  # Mogán
                    ],
                }
                
                API_KEY = os.getenv("AEMET_API_KEY")
                HEADERS = {
                    "Accept": "application/json",
                    "api_key": API_KEY
                }
                
                # Función para obtener la predicción diaria para un municipio
                def fetch_daily_forecast(mun_code):
                    url = f"https://opendata.aemet.es/opendata/api/prediccion/especifica/municipio/diaria/{mun_code}"
                    r1 = requests.get(url, headers=HEADERS, timeout=10)
                    r1.raise_for_status()
                    meta = r1.json()
                    
                    if isinstance(meta, dict) and meta.get("datos"):
                        r2 = requests.get(meta["datos"], headers=HEADERS, timeout=10)
                        r2.raise_for_status()
                        payload = r2.json()
                    else:
                        payload = meta if isinstance(meta, list) else []
                    
                    if isinstance(payload, list) and payload:
                        return payload[0].get("prediccion", {}).get("dia", [])
                    elif isinstance(payload, dict):
                        return payload.get("prediccion", {}).get("dia", [])
                    else:
                        return []
                
                # Función para guardar la predicción de una zona en un archivo CSV
                def save_zone_forecast_csv(zona, mun_codes):
                    zona_data = {}
                    
                    for code in mun_codes:
                        dias = fetch_daily_forecast(code)
                        for dia in dias:
                            fecha = dia.get("fecha", "")
                            temp = dia.get("temperatura", {})
                            tmax = temp.get("maxima")
                            tmin = temp.get("minima")
                            if tmax is None or tmin is None:
                                continue
                            tmedia = (tmax + tmin) / 2
                            zona_data.setdefault(fecha, []).append(tmedia)
                        time.sleep(1)
                    
                    # Generar slug de zona: últimos dos términos en minúsculas unidos por "_"
                    slug = "_".join(zona.split()[-2:]).lower()
                    fname = os.path.join(DATA_DIR, f"{slug}-{fecha_actual}.csv")
                    
                    with open(fname, "w", newline="", encoding="utf-8") as f:
                        w = csv.writer(f)
                        w.writerow(["Fecha", "Tmedia_zonal"])
                        for fecha, tmedias in sorted(zona_data.items()):
                            if not tmedias:
                                continue
                            media_zonal = sum(tmedias) / len(tmedias)
                            w.writerow([fecha, f"{media_zonal:.1f}"])
                    
                    print(f"Guardado zona: {fname}")
                    return fname
                
                # Asegurar que el directorio de datos existe
                os.makedirs(DATA_DIR, exist_ok=True)
                
                # Generar los archivos CSV para cada zona
                archivos_generados = []
                for zona, codes in ZONAS.items():
                    try:
                        archivo = save_zone_forecast_csv(zona, codes)
                        archivos_generados.append(archivo)
                    except Exception as e:
                        print(f"Error en zona {zona}: {e}")
                
                # Verificar que se hayan generado todos los archivos
                if len(archivos_generados) != 3:
                    raise HTTPException(
                        status_code=500,
                        detail=f"No se pudieron generar todos los archivos CSV necesarios. Solo se generaron {len(archivos_generados)} de 3."
                    )
                
                # Verificar que los archivos existen después de generarlos
                if not (os.path.exists(csv_norte) and os.path.exists(csv_este) and os.path.exists(csv_sur)):
                    raise HTTPException(
                        status_code=500,
                        detail="No se encontraron todos los archivos CSV necesarios después de generarlos."
                    )
                
            except Exception as e:
                # Capturar cualquier excepción y devolver un mensaje de error detallado
                raise HTTPException(
                    status_code=500,
                    detail=f"Error al generar los archivos CSV: {str(e)}"
                )
        
        # Leer los archivos CSV
        try:
            # Diccionarios para almacenar los datos por fecha
            datos_norte = {}
            datos_este = {}
            datos_sur = {}
            
            # Leer datos del norte
            with open(csv_norte, 'r', encoding='utf-8') as csvfile:
                reader = csv.DictReader(csvfile)
                for row in reader:
                    fecha_csv = row['Fecha'].split('T')[0]  # Extraer solo la parte de la fecha
                    tmedia = float(row['Tmedia_zonal']) if row['Tmedia_zonal'] else None
                    datos_norte[fecha_csv] = tmedia
            
            # Leer datos del este
            with open(csv_este, 'r', encoding='utf-8') as csvfile:
                reader = csv.DictReader(csvfile)
                for row in reader:
                    fecha_csv = row['Fecha'].split('T')[0]  # Extraer solo la parte de la fecha
                    tmedia = float(row['Tmedia_zonal']) if row['Tmedia_zonal'] else None
                    datos_este[fecha_csv] = tmedia
            
            # Leer datos del sur
            with open(csv_sur, 'r', encoding='utf-8') as csvfile:
                reader = csv.DictReader(csvfile)
                for row in reader:
                    fecha_csv = row['Fecha'].split('T')[0]  # Extraer solo la parte de la fecha
                    tmedia = float(row['Tmedia_zonal']) if row['Tmedia_zonal'] else None
                    datos_sur[fecha_csv] = tmedia
            
            # Si se especificó una fecha, validar y filtrar los datos
            if fecha:
                # Validar formato de fecha
                if not re.match(r'^\d{8}$', fecha):
                    raise HTTPException(
                        status_code=400, 
                        detail="Formato de fecha incorrecto. Debe ser YYYYMMDD (ej: 20250522)"
                    )
                
                # Convertir formato YYYYMMDD a YYYY-MM-DD
                fecha_formateada = f"{fecha[:4]}-{fecha[4:6]}-{fecha[6:8]}"
                
                # Validar que la fecha no sea futura más allá de 7 días
                fecha_consulta = datetime.strptime(fecha_formateada, "%Y-%m-%d").date()
                hoy = date.today()
                max_fecha = hoy + timedelta(days=7)
                
                if fecha_consulta > max_fecha:
                    raise HTTPException(
                        status_code=400, 
                        detail="No se permiten consultas para fechas futuras más allá de 7 días"
                    )
                
                # Verificar si la fecha existe en los datos
                if fecha_formateada not in datos_norte or fecha_formateada not in datos_este or fecha_formateada not in datos_sur:
                    raise HTTPException(
                        status_code=404, 
                        detail=f"No se encontraron datos para la fecha {fecha_formateada}"
                    )
                
                # Devolver solo los datos para la fecha especificada
                return {
                    "tmedia_norte": datos_norte.get(fecha_formateada),
                    "tmedia_este": datos_este.get(fecha_formateada),
                    "tmedia_sur": datos_sur.get(fecha_formateada)
                }
            else:
                # Devolver todos los datos disponibles
                resultado = []
                
                # Obtener todas las fechas únicas de los tres archivos
                todas_fechas = sorted(set(list(datos_norte.keys()) + list(datos_este.keys()) + list(datos_sur.keys())))
                
                for fecha_csv in todas_fechas:
                    resultado.append({
                        "fecha": fecha_csv,
                        "tmedia_norte": datos_norte.get(fecha_csv),
                        "tmedia_este": datos_este.get(fecha_csv),
                        "tmedia_sur": datos_sur.get(fecha_csv)
                    })
                
                return resultado
                
        except Exception as e:
            raise HTTPException(
                status_code=500,
                detail=f"Error al leer los archivos CSV: {str(e)}"
            )
            
    except Exception as e:
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail=str(e))

# Endpoint para obtener datos históricos de consumo REE
@app.get("/consree")
async def consumo_historico_ree(fecha: str = Query(..., description="Fecha en formato YYYYMMDD")):
    try:
        # Validar formato de fecha
        if not re.match(r'^\d{8}$', fecha):
            raise HTTPException(
                status_code=400, 
                detail="Formato de fecha incorrecto. Debe ser YYYYMMDD (ej: 20250522)"
            )
        
        # Convertir formato YYYYMMDD a YYYY-MM-DD para buscar en el CSV
        fecha_formateada = f"{fecha[:4]}-{fecha[4:6]}-{fecha[6:8]}"
        
        # Ruta al archivo CSV
        csv_filename = os.path.join(DATA_DIR, "cons_ener_gc-ree.csv")
        
        # Verificar que el archivo exista
        if not os.path.exists(csv_filename):
            raise HTTPException(
                status_code=500, 
                detail=f"El archivo {csv_filename} no existe"
            )
        
        # Buscar la fecha en el archivo CSV
        try:
            with open(csv_filename, 'r') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    if row["fecha"] == fecha_formateada:
                        return {
                            "real": int(float(row["real"])),
                            "prevista": int(float(row["prevista"]))
                        }
                
                # Si llegamos aquí, no se encontró la fecha
                return {"error": "No hay datos"}
                
        except Exception as e:
            raise HTTPException(
                status_code=500, 
                detail=f"Error al leer el archivo CSV: {str(e)}"
            )
            
    except Exception as e:
        if isinstance(e, HTTPException):
            raise e
        else:
            raise HTTPException(
                status_code=500, 
                detail=f"Error inesperado: {str(e)}"
            )

# Endpoint para obtener datos históricos de temperatura y humedad
@app.get("/temphis")
async def temperatura_historica(fecha: str = Query(..., description="Fecha en formato YYYYMMDD")):
    try:
        # Validar formato de fecha
        if not re.match(r'^\d{8}$', fecha):
            raise HTTPException(
                status_code=400, 
                detail="Formato de fecha incorrecto. Debe ser YYYYMMDD (ej: 20250522)"
            )
        
        # Convertir formato YYYYMMDD a YYYY-MM-DD para buscar en el CSV
        fecha_formateada = f"{fecha[:4]}-{fecha[4:6]}-{fecha[6:8]}"
        
        # Ruta al archivo CSV
        csv_filename = os.path.join(DATA_DIR, "dataset_zonas_new.csv")
        
        # Verificar que el archivo exista
        if not os.path.exists(csv_filename):
            raise HTTPException(
                status_code=500, 
                detail=f"El archivo {csv_filename} no existe"
            )
        
        # Buscar la fecha en el archivo CSV
        try:
            with open(csv_filename, 'r') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    if row["fecha"] == fecha_formateada:
                        return {
                            "temp_norte": float(row["temp_norte"]),
                            "temp_este": float(row["temp_este"]),
                            "temp_sur": float(row["temp_sur"]),
                            "hum_norte": float(row["hum_norte"]),
                            "hum_este": float(row["hum_este"]),
                            "hum_sur": float(row["hum_sur"])
                        }
                
                # Si llegamos aquí, no se encontró la fecha
                return {"error": "No hay datos"}
                
        except Exception as e:
            raise HTTPException(
                status_code=500, 
                detail=f"Error al leer el archivo CSV: {str(e)}"
            )
            
    except Exception as e:
        if isinstance(e, HTTPException):
            raise e
        else:
            raise HTTPException(
                status_code=500, 
                detail=f"Error inesperado: {str(e)}"
            )

# Nuevo endpoint para obtener datos históricos de consumo ISTAC
@app.get("/consistac")
async def consumo_historico_istac(fecha: str = Query(..., description="Fecha en formato YYYYMMDD")):
    try:
        # Validar formato de fecha
        if not re.match(r'^\d{8}$', fecha):
            raise HTTPException(
                status_code=400, 
                detail="Formato de fecha incorrecto. Debe ser YYYYMMDD (ej: 20250522)"
            )
        
        # Convertir formato YYYYMMDD a YYYY-MM-DD para buscar en el CSV
        fecha_formateada = f"{fecha[:4]}-{fecha[4:6]}-{fecha[6:8]}"
        
        # Ruta al archivo CSV
        csv_filename = os.path.join(DATA_DIR, "cons_ener_gc-istac.csv")
        
        # Verificar que el archivo exista
        if not os.path.exists(csv_filename):
            raise HTTPException(
                status_code=500, 
                detail=f"El archivo {csv_filename} no existe"
            )
        
        # Buscar la fecha en el archivo CSV
        try:
            with open(csv_filename, 'r') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    if row["fecha"] == fecha_formateada:
                        return {
                            "real": int(float(row["real"]))
                        }
                
                # Si llegamos aquí, no se encontró la fecha
                return {"error": "No hay datos"}
                
        except Exception as e:
            raise HTTPException(
                status_code=500, 
                detail=f"Error al leer el archivo CSV: {str(e)}"
            )
            
    except Exception as e:
        if isinstance(e, HTTPException):
            raise e
        else:
            raise HTTPException(
                status_code=500, 
                detail=f"Error inesperado: {str(e)}"
            )

# Punto de entrada para ejecutar la aplicación
if __name__ == "__main__":
    uvicorn.run("api:app", host="0.0.0.0", port=8000, reload=True)
