#!/usr/bin/env python3
import os
import sys
import time
from datetime import datetime

import pandas as pd
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

# Factor para pasar potencia promedio (MW) medida cada 5 min a energía (MWh)
INTERVAL_MINUTES = 5
HOUR_FACTOR = INTERVAL_MINUTES / 60.0

def download_csv_with_selenium(fecha: str, download_dir: str = ".") -> str:
    opts = Options()
    opts.add_argument("--headless=new")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-gpu")
    opts.add_experimental_option("prefs", {
        "download.default_directory": os.path.abspath(download_dir),
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True
    })
    opts.add_argument("--window-size=1920,1080")
    opts.add_argument("--log-level=3")

    driver = webdriver.Chrome(
        service=Service(ChromeDriverManager().install()),
        options=opts
    )
    try:
        url = f"https://demanda.ree.es/visiona/canarias/gcanariaau/tablas/{fecha}/1"
        driver.get(url)

        wait = WebDriverWait(driver, 15)
        btn = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, ".export-csv a")))
        driver.execute_script("arguments[0].scrollIntoView({block:'center'});", btn)

        before = {f for f in os.listdir(download_dir) if f.lower().endswith(".csv")}
        driver.execute_script("arguments[0].click();", btn)

        deadline = time.time() + 30
        while time.time() < deadline:
            now = {f for f in os.listdir(download_dir) if f.lower().endswith(".csv")}
            new = now - before
            if new:
                return os.path.join(download_dir, new.pop())
            time.sleep(0.5)
        raise RuntimeError(f"Timeout: no se descargó CSV para {fecha}")
    finally:
        driver.quit()


def process_csv(raw_csv: str, fecha: str) -> tuple:
    # Lee CSV y extrae columnas Hora, Real y Prevista
    with open(raw_csv, encoding='latin1') as f:
        lines = f.readlines()

    header_idx = next((i for i, l in enumerate(lines) if l.strip().lower().startswith("hora,")), None)
    if header_idx is None:
        raise RuntimeError(f"No encontré 'Hora,' en {raw_csv}")

    rows = []
    for line in lines[header_idx+1:]:
        line = line.strip()
        if not line:
            continue
        parts = line.split(',')
        if len(parts) < 3:
            continue
        hora = parts[0].strip().strip('"')
        real = parts[1].strip().strip('"')
        prevista = parts[2].strip().strip('"')
        rows.append((hora, real, prevista))

    df = pd.DataFrame(rows, columns=['Hora', 'Real', 'Prevista'])
    df['Hora'] = pd.to_datetime(df['Hora'], format='%Y-%m-%d %H:%M', errors='coerce')
    df['Real'] = pd.to_numeric(df['Real'], errors='coerce')
    df['Prevista'] = pd.to_numeric(df['Prevista'], errors='coerce')

    # Filtrar sólo la fecha objetivo
    target = pd.to_datetime(fecha).date()
    df = df[df['Hora'].dt.date == target]

    # Convertir potencia (MW) cada intervalo a energía (MWh)
    df['Real_MWh'] = df['Real'] * HOUR_FACTOR
    df['Prevista_MWh'] = df['Prevista'] * HOUR_FACTOR

    # Sumar energía diaria en MWh y redondear a entero
    total_real = round(df['Real_MWh'].sum())
    total_prevista = round(df['Prevista_MWh'].sum())

    return total_real, total_prevista


def main():
    if len(sys.argv) != 2:
        print("Uso: python des.py YYYY-MM-DD")
        sys.exit(1)

    try:
        fecha = datetime.strptime(sys.argv[1], "%Y-%m-%d").date().isoformat()
    except ValueError:
        print("ERROR: usa formato YYYY-MM-DD para la fecha")
        sys.exit(1)

    cwd = os.getcwd()
    try:
        raw = download_csv_with_selenium(fecha, cwd)
        real, prevista = process_csv(raw, fecha)
        # Eliminar el fichero CSV bruto tras el proceso
        try:
            os.remove(raw)
        except OSError:
            print(f"  ⚠️ No se pudo eliminar: {raw}")
        # Mostrar resultado en pantalla
        print(f" R: {real}, P: {prevista}")
    except Exception as e:
        print(f"  !!! Error en {fecha}: {e}")


if __name__ == "__main__":
    main()
