#!/usr/bin/env python3
import os
import sys
import requests
from datetime import datetime
from statistics import mean
from typing import List, Dict, Any
import time
import csv

API_KEY = os.getenv("AEMET_API_KEY")
if not API_KEY:
    sys.exit("ERROR: define tu clave en la variable de entorno AEMET_API_KEY")

## 1) Define DATA_DIR (por defecto “data”)
DATA_DIR = os.getenv("DATA_DIR", "data")
os.makedirs(DATA_DIR, exist_ok=True)

# Definición de zonas con sus estaciones
ZONAS: Dict[str, List[str]] = {
    "Norte": ["C658X", "C669B"],
    "Este": ["C648C", "C648N", "C649I", "C649R"],
    "Sur": ["C629Q", "C629X", "C635B", "C639U"],
}

HEADERS = {"Accept": "application/json", "api_key": API_KEY}


def fetch_hourly_observations(station_id: str, date: str) -> List[Dict[str, Any]]:
    """
    Descarga observaciones horarias de una estación para un día.
    """
    base = "https://opendata.aemet.es/opendata/api/observacion/convencional/datos/estacion"
    params = {"fechaInicio": date, "fechaFin": date}
    r1 = requests.get(f"{base}/{station_id}", headers=HEADERS, params=params, timeout=10)
    r1.raise_for_status()
    meta = r1.json()
    link = meta.get("datos")
    if not link:
        return []
    r2 = requests.get(link, timeout=10)
    r2.raise_for_status()
    return r2.json()


def compute_daily_averages(obs: List[Dict[str, Any]], date: str):
    """
    Calcula temperatura y humedad medias para la fecha dada.
    """
    temps, hums = [], []
    for rec in obs:
        fint = rec.get("fint", "")
        if not fint.startswith(date):
            continue
        t = rec.get("ta")
        h = rec.get("hr")
        if isinstance(t, (int, float)):
            temps.append(t)
        if isinstance(h, (int, float)):
            hums.append(h)
    if not temps or not hums:
        return None, None
    return mean(temps), mean(hums)


def main():
    if len(sys.argv) != 2:
        print(f"Uso: {sys.argv[0]} <YYYY-MM-DD>")
        sys.exit(1)

    date_str = sys.argv[1]
    try:
        datetime.strptime(date_str, "%Y-%m-%d")
    except ValueError:
        sys.exit("Fecha inválida, formato debe ser YYYY-MM-DD")

    # Almacenamos resultados por zona
    results = {}
    for zona, estaciones in ZONAS.items():
        zone_temps, zone_hums = [], []
        for est in estaciones:
            try:
                obs = fetch_hourly_observations(est, date_str)
                t_med, h_med = compute_daily_averages(obs, date_str)
                if t_med is not None:
                    zone_temps.append(t_med)
                if h_med is not None:
                    zone_hums.append(h_med)
            except Exception as e:
                print(f"  !! Error estación {est}: {e}")
            time.sleep(1)
        if zone_temps and zone_hums:
            results[zona] = {
                'temp': mean(zone_temps),
                'hum': mean(zone_hums)
            }
        else:
            results[zona] = {
                'temp': None,
                'hum': None
            }

    # Nombre de archivo temp_diaYYYYMMDD.csv
    date_csv = date_str.replace("-", "")
    fname = os.path.join(DATA_DIR, f"temp_dia{date_csv}.csv")

    # Escribir CSV
    with open(fname, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        # Cabecera
        header = [
            'fecha',
            'temp_norte', 'temp_este', 'temp_sur',
            'hum_norte', 'hum_este', 'hum_sur'
        ]
        writer.writerow(header)
        # Datos (convertir None a cadena vacía si es necesario)
        row = [date_str]
        for zona_key in ['Norte', 'Este', 'Sur']:
            val = results.get(zona_key, {})
            t = val.get('temp')
            h = val.get('hum')
            row.append(f"{t:.1f}" if isinstance(t, float) else '')
        for zona_key in ['Norte', 'Este', 'Sur']:
            val = results.get(zona_key, {})
            h = val.get('hum')
            row.append(f"{h:.1f}" if isinstance(h, float) else '')
        writer.writerow(row)

    print(f"CSV guardado: {fname}")


if __name__ == "__main__":
    main()