#!/usr/bin/env python3
import os
import sys
import time
import csv
import requests
from datetime import datetime
from typing import Dict, List, Any

API_KEY = os.getenv("AEMET_API_KEY")
if not API_KEY:
    raise SystemExit("ERROR: define tu clave en la variable de entorno AEMET_API_KEY")

# Obtener el directorio de datos desde la variable de entorno o usar el directorio actual
# Después: por defecto guardamos en la carpeta ./data
DATA_DIR = os.getenv("DATA_DIR", "data")

# Definición de zonas: nombre → lista de códigos de municipio
ZONAS: Dict[str, List[str]] = {
    "Gran_Canaria Norte": [
        "35016",  # Las Palmas de Gran Canaria
        "35004",  # Arucas
        "35022",  # Gáldar
    ],
    "Gran_Canaria Este": [
        "35035",  # Telde
        "35012",  # Ingenio
        "35005",  # Agüimes
    ],
    "Gran_Canaria Sur": [
        "35037",  # San Bartolomé de Tirajana
        "35036",  # Santa Lucía de Tirajana
        "35018",  # Mogán
    ],
}

HEADERS = {
    "Accept": "application/json",
    "api_key": API_KEY
}

# Fecha de descarga en formato YYYYMMDD
DATE_STR = datetime.now().strftime("%Y%m%d")


def fetch_daily_forecast(mun_code: str) -> List[Dict[str, Any]]:
    """
    Descarga la predicción diaria para un municipio y devuelve la lista de días.
    """
    url = f"https://opendata.aemet.es/opendata/api/prediccion/especifica/municipio/diaria/{mun_code}"
    r1 = requests.get(url, headers=HEADERS, timeout=10)
    r1.raise_for_status()
    meta = r1.json()

    # Si la respuesta es un dict con enlace en meta["datos"], seguimos ese enlace
    if isinstance(meta, dict) and meta.get("datos"):
        r2 = requests.get(meta["datos"], headers=HEADERS, timeout=10)
        r2.raise_for_status()
        payload = r2.json()
    else:
        payload = meta if isinstance(meta, list) else []

    # Extraemos la lista de días
    if isinstance(payload, list) and payload:
        return payload[0].get("prediccion", {}).get("dia", [])
    elif isinstance(payload, dict):
        return payload.get("prediccion", {}).get("dia", [])
    else:
        return []


def save_zone_forecast_csv(zona: str, mun_codes: List[str]):
    """
    Para una zona, obtiene cada municipio, calcula Tmedia por día y promedia
    todas las Tmedias de los municipios para dar una Tmedia zonal.
    Guarda el CSV con nombre <slug_zona>-<fecha>.csv
    """
    zona_data: Dict[str, List[float]] = {}

    for code in mun_codes:
        dias = fetch_daily_forecast(code)
        for dia in dias:
            fecha = dia.get("fecha", "")
            temp = dia.get("temperatura", {})
            tmax = temp.get("maxima")
            tmin = temp.get("minima")
            if tmax is None or tmin is None:
                continue
            tmedia = (tmax + tmin) / 2
            zona_data.setdefault(fecha, []).append(tmedia)
        time.sleep(1)

    # Generar slug de zona: últimos dos términos en minúsculas unidos por "_"
    slug = "_".join(zona.split()[-2:]).lower()
    fname = os.path.join(DATA_DIR, f"{slug}-{DATE_STR}.csv")

    with open(fname, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["Fecha", "Tmedia_zonal"])
        for fecha, tmedias in sorted(zona_data.items()):
            if not tmedias:
                continue
            media_zonal = sum(tmedias) / len(tmedias)
            w.writerow([fecha, f"{media_zonal:.1f}"])
    print(f"  ✓ Guardado zona: {fname}")


def main():
    # Asegurar que el directorio de datos existe
    os.makedirs(DATA_DIR, exist_ok=True)
    
    # Solo predicción agregada por zona
    for zona, codes in ZONAS.items():
        try:
            print(f"\n→ Zona: {zona}")
            save_zone_forecast_csv(zona, codes)
        except Exception as e:
            print(f"  !! Error en zona {zona}: {e}")


if __name__ == "__main__":
    main()
